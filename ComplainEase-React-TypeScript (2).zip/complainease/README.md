# ComplainEase — React + TypeScript

A frontend-only complaint-management prototype using React, TypeScript, Vite and browser LocalStorage.

## Requirements
- Node.js 20.19+ or 22.12+
- npm (included with Node.js)

## Install and run
1. Extract the ZIP file.
2. Open the `complainease` folder in VS Code.
3. Open Terminal → New Terminal.
4. Run:

   ```bash
   npm install
   npm run dev
   ```

5. Open the local URL printed by Vite (normally http://localhost:5173).

## Build check
Run:

```bash
npm run build
```

A successful build creates the `dist` folder.

## Features
- User registration and sign-in
- Submit complaint with category, title, description and optional attachment filename
- Complaint history and status/feedback display
- Demo admin dashboard to update status and feedback
- FAQ/help page
- Responsive layout
- Data persistence in LocalStorage

## Demo admin
- Email: `admin@complainease.demo`
- Password: `Admin@123`

Choose **Admin demo** in the footer and enter these credentials.

## Sample test
1. Open the app and create a user account with a valid email and password of at least 6 characters.
2. Sign in and select **New complaint**.
3. Submit a complaint, for example:
   - Category: Payment Problem
   - Title: Payment deducted but order not confirmed
   - Description: The amount was deducted from my account, but I did not receive an order confirmation.
4. Open **My complaints** and note the complaint reference ID. The status should be Pending.
5. Use **Admin demo** in the footer and enter the demo admin credentials.
6. Change the complaint status to In Progress, edit the feedback and click Save update.
7. Return to the user session (sign out of admin by clicking Close admin, then use the user account) and open My complaints to verify the update.
8. Refresh the browser. User and complaint data should remain because they are saved in LocalStorage.

## Important limitations
This is a learning/demo frontend, not a production service:
- LocalStorage data belongs to the current browser and device; it is not shared between users or devices.
- Passwords are stored in plain text in this demo. Do not use real passwords or personal data.
- Admin credentials are visible in frontend source code and are not secure.
- The attachment field stores only a filename; it does not upload a file.
- Email and SMS notifications are not connected.
- There is no server-side authorization or database backup.

For real deployment, use a backend, secure password hashing, server-enforced role permissions, database storage, validated file uploads and a trusted email/SMS provider.
