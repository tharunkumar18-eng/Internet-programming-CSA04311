import { useEffect, useMemo, useState } from "react";

type Status = "Pending" | "In Progress" | "Resolved" | "Rejected";
type Page = "home" | "login" | "register" | "submit" | "history" | "admin" | "help";

interface User {
  id: string;
  name: string;
  email: string;
  password: string;
}
interface Complaint {
  id: string;
  userId: string;
  userName: string;
  email: string;
  category: string;
  title: string;
  description: string;
  attachmentName: string;
  status: Status;
  feedback: string;
  createdAt: string;
  updatedAt: string;
}

const USERS_KEY = "complainease_users_v1";
const COMPLAINTS_KEY = "complainease_complaints_v1";
const SESSION_KEY = "complainease_session_v1";
const ADMIN_EMAIL = "admin@complainease.demo";
const ADMIN_PASSWORD = "Admin@123";

function readStorage<T>(key: string, fallback: T): T {
  try {
    const value = localStorage.getItem(key);
    return value ? (JSON.parse(value) as T) : fallback;
  } catch {
    return fallback;
  }
}

function makeId(): string {
  return `CE-${Date.now().toString(36).toUpperCase()}-${Math.random()
    .toString(36)
    .slice(2, 6)
    .toUpperCase()}`;
}

const faqs = [
  ["How do I submit a complaint?", "Sign in, choose Submit Complaint, complete the form and press Submit Complaint."],
  ["How can I track a complaint?", "Open My Complaints to see its reference number, current status and latest feedback."],
  ["What does In Progress mean?", "The complaint has been reviewed and is being handled by the resolution team."],
  ["Can I add more evidence later?", "This demo records one optional attachment name at submission. A production system should use secure file storage."],
];

export default function App() {
  const [users, setUsers] = useState<User[]>(() => readStorage(USERS_KEY, []));
  const [complaints, setComplaints] = useState<Complaint[]>(() => readStorage(COMPLAINTS_KEY, []));
  const [session, setSession] = useState<User | null>(() => readStorage<User | null>(SESSION_KEY, null));
  const [page, setPage] = useState<Page>("home");
  const [notice, setNotice] = useState("");
  const [isAdmin, setIsAdmin] = useState(false);
  const [auth, setAuth] = useState({ name: "", email: "", password: "" });
  const [form, setForm] = useState({ category: "Technical Issue", title: "", description: "" });
  const [attachmentName, setAttachmentName] = useState("");
  const [search, setSearch] = useState("");

  useEffect(() => localStorage.setItem(USERS_KEY, JSON.stringify(users)), [users]);
  useEffect(() => localStorage.setItem(COMPLAINTS_KEY, JSON.stringify(complaints)), [complaints]);
  useEffect(() => {
    if (session) localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    else localStorage.removeItem(SESSION_KEY);
  }, [session]);

  const myComplaints = useMemo(
    () => complaints.filter((item) => item.userId === session?.id),
    [complaints, session],
  );
  const matchingComplaints = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return complaints;
    return complaints.filter((item) =>
      [item.id, item.title, item.category, item.description, item.email]
        .some((value) => value.toLowerCase().includes(term)),
    );
  }, [complaints, search]);

  function notify(message: string) {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 4000);
  }

  function register() {
    const name = auth.name.trim();
    const email = auth.email.trim().toLowerCase();
    if (!name || !email || !auth.password) return notify("Please complete all fields.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return notify("Enter a valid email address.");
    if (auth.password.length < 6) return notify("Password must contain at least 6 characters.");
    if (users.some((item) => item.email === email)) return notify("An account with this email already exists.");

    const newUser: User = { id: makeId(), name, email, password: auth.password };
    setUsers((current) => [...current, newUser]);
    setSession(newUser);
    setAuth({ name: "", email: "", password: "" });
    setPage("home");
    notify("Account created. You are now signed in.");
  }

  function login() {
    const email = auth.email.trim().toLowerCase();
    const found = users.find((item) => item.email === email && item.password === auth.password);
    if (!found) return notify("Incorrect email or password.");
    setSession(found);
    setAuth({ name: "", email: "", password: "" });
    setPage("home");
    notify(`Welcome back, ${found.name}.`);
  }

  function submitComplaint() {
    if (!session) return notify("Please sign in first.");
    const title = form.title.trim();
    const description = form.description.trim();
    if (!title || !description) return notify("Please enter a title and description.");
    if (title.length > 100) return notify("Title must be 100 characters or fewer.");
    if (description.length > 2000) return notify("Description must be 2,000 characters or fewer.");

    const now = new Date().toISOString();
    const item: Complaint = {
      id: makeId(),
      userId: session.id,
      userName: session.name,
      email: session.email,
      category: form.category,
      title,
      description,
      attachmentName,
      status: "Pending",
      feedback: "Your complaint has been registered and is awaiting review.",
      createdAt: now,
      updatedAt: now,
    };
    setComplaints((current) => [item, ...current]);
    setForm({ category: "Technical Issue", title: "", description: "" });
    setAttachmentName("");
    setPage("history");
    notify(`Complaint submitted. Reference: ${item.id}`);
  }

  function updateComplaint(id: string, status: Status, feedback: string) {
    setComplaints((current) =>
      current.map((item) =>
        item.id === id
          ? { ...item, status, feedback: feedback.trim() || `Status updated to ${status}.`, updatedAt: new Date().toISOString() }
          : item,
      ),
    );
    notify("Complaint updated.");
  }

  function logout() {
    setSession(null);
    setIsAdmin(false);
    setPage("home");
    notify("You have signed out.");
  }

  function openAdmin() {
    const email = window.prompt("Demo admin email:");
    if (email !== ADMIN_EMAIL) return notify("Admin sign-in failed.");
    const password = window.prompt("Demo admin password:");
    if (password !== ADMIN_PASSWORD) return notify("Admin sign-in failed.");
    setIsAdmin(true);
    setPage("admin");
  }

  const resolvedCount = complaints.filter((item) => item.status === "Resolved").length;
  const pendingCount = complaints.filter((item) => item.status === "Pending").length;

  return (
    <div className="app-shell">
      <header className="site-header">
        <div className="brand">
          <div className="brand-mark">C</div>
          <div><strong>ComplainEase</strong><span>Your voice. Our responsibility.</span></div>
        </div>
        <nav aria-label="Main navigation">
          <button className="nav-link" onClick={() => setPage("home")}>Home</button>
          <button className="nav-link" onClick={() => setPage("help")}>Help</button>
          {session ? (
            <>
              <button className="nav-link" onClick={() => setPage("submit")}>New complaint</button>
              <button className="nav-link" onClick={() => setPage("history")}>My complaints</button>
              <button className="nav-cta" onClick={logout}>Sign out</button>
            </>
          ) : (
            <>
              <button className="nav-link" onClick={() => setPage("login")}>Sign in</button>
              <button className="nav-cta" onClick={() => setPage("register")}>Create account</button>
            </>
          )}
        </nav>
      </header>

      {notice && <div className="toast" role="status">{notice}</div>}

      <main>
        {page === "home" && (
          <>
            <section className="hero">
              <div className="hero-copy">
                <span className="eyebrow">COMPLAINT MANAGEMENT, MADE SIMPLE</span>
                <h1>Speak up. Get heard.<br /><em>Get it resolved.</em></h1>
                <p>Register a concern, follow every update and stay informed throughout the resolution process.</p>
                <div className="hero-actions">
                  <button className="primary-btn" onClick={() => setPage(session ? "submit" : "register")}>Register a complaint <span>→</span></button>
                  <button className="text-btn" onClick={() => setPage("help")}>How it works</button>
                </div>
                <div className="trust-note"><span className="check-dot">✓</span> Transparent tracking from submission to resolution</div>
              </div>
              <div className="hero-card">
                <div className="card-top"><span className="live-dot" /> COMPLAINT OVERVIEW <span className="demo-tag">LIVE DEMO</span></div>
                <div className="overview-number">{complaints.length.toString().padStart(2, "0")}<small> complaints registered</small></div>
                <div className="progress-row"><span>Resolved</span><strong>{resolvedCount}</strong></div>
                <div className="progress-track"><div style={{ width: `${complaints.length ? (resolvedCount / complaints.length) * 100 : 0}%` }} /></div>
                <div className="mini-stats">
                  <div><b>{pendingCount}</b><span>Pending</span></div>
                  <div><b>{complaints.filter((item) => item.status === "In Progress").length}</b><span>In progress</span></div>
                  <div><b>{resolvedCount}</b><span>Resolved</span></div>
                </div>
                <div className="card-foot">Your complaint matters. We’re here to help.</div>
              </div>
            </section>
            <section className="steps-section">
              <div className="section-heading"><span className="eyebrow">A CLEARER WAY FORWARD</span><h2>Resolution in three simple steps</h2></div>
              <div className="steps-grid">
                <article className="step-card"><span className="step-no">01</span><h3>Submit</h3><p>Tell us what happened. Choose a category and provide the details.</p></article>
                <article className="step-card"><span className="step-no">02</span><h3>Track</h3><p>Use your complaint history to check the latest status and feedback.</p></article>
                <article className="step-card"><span className="step-no">03</span><h3>Resolve</h3><p>The resolution team reviews the issue and updates its progress.</p></article>
              </div>
            </section>
          </>
        )}

        {page === "register" && (
          <section className="form-panel narrow">
            <span className="eyebrow">GET STARTED</span><h2>Create your account</h2><p className="muted">Register to submit and track your complaints.</p>
            <label>Full name<input value={auth.name} onChange={(e) => setAuth({ ...auth, name: e.target.value })} placeholder="Enter your name" autoComplete="name" /></label>
            <label>Email address<input type="email" value={auth.email} onChange={(e) => setAuth({ ...auth, email: e.target.value })} placeholder="you@example.com" autoComplete="email" /></label>
            <label>Password<input type="password" value={auth.password} onChange={(e) => setAuth({ ...auth, password: e.target.value })} placeholder="At least 6 characters" autoComplete="new-password" /></label>
            <button className="primary-btn full-btn" onClick={register}>Create account →</button>
            <p className="form-switch">Already registered? <button onClick={() => setPage("login")}>Sign in</button></p>
          </section>
        )}

        {page === "login" && (
          <section className="form-panel narrow">
            <span className="eyebrow">WELCOME BACK</span><h2>Sign in to ComplainEase</h2><p className="muted">Access your complaint dashboard.</p>
            <label>Email address<input type="email" value={auth.email} onChange={(e) => setAuth({ ...auth, email: e.target.value })} placeholder="you@example.com" autoComplete="email" /></label>
            <label>Password<input type="password" value={auth.password} onChange={(e) => setAuth({ ...auth, password: e.target.value })} placeholder="Enter your password" autoComplete="current-password" /></label>
            <button className="primary-btn full-btn" onClick={login}>Sign in →</button>
            <p className="form-switch">New here? <button onClick={() => setPage("register")}>Create an account</button></p>
          </section>
        )}

        {page === "submit" && (
          <section className="form-panel">
            <span className="eyebrow">WE’RE LISTENING</span><h2>Submit a complaint</h2><p className="muted">Please provide clear information so the team can understand your concern.</p>
            <label>Category<select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
              <option>Technical Issue</option><option>Payment Problem</option><option>Customer Service</option><option>Product Complaint</option><option>Delivery / Service Delay</option><option>Other</option>
            </select></label>
            <label>Complaint title<input maxLength={100} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Briefly describe your issue" /></label>
            <label>Description<textarea maxLength={2000} rows={6} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Include dates, events and any relevant details..." /></label>
            <label>Supporting document name <input value={attachmentName} onChange={(e) => setAttachmentName(e.target.value)} placeholder="Optional: e.g. receipt.pdf (name only)" /></label>
            <p className="field-note">This LocalStorage demo records the file name only; it does not upload or store the document.</p>
            <button className="primary-btn" onClick={submitComplaint}>Submit complaint →</button>
          </section>
        )}

        {page === "history" && (
          <section className="content-panel">
            <div className="panel-heading"><div><span className="eyebrow">YOUR ACCOUNT</span><h2>My complaints</h2><p className="muted">Review your submitted complaints and their latest updates.</p></div><button className="primary-btn" onClick={() => setPage("submit")}>+ New complaint</button></div>
            {myComplaints.length === 0 ? <div className="empty-state"><div className="empty-icon">◎</div><h3>No complaints yet</h3><p>Your submitted complaints will appear here.</p><button className="primary-btn" onClick={() => setPage("submit")}>Submit your first complaint</button></div> : (
              <div className="complaint-list">{myComplaints.map((item) => <ComplaintCard key={item.id} item={item} />)}</div>
            )}
          </section>
        )}

        {page === "admin" && isAdmin && (
          <section className="content-panel">
            <div className="panel-heading"><div><span className="eyebrow">STAFF WORKSPACE</span><h2>Admin dashboard</h2><p className="muted">Review submitted complaints and update their progress.</p></div><button className="secondary-btn" onClick={() => { setIsAdmin(false); setPage("home"); }}>Close admin</button></div>
            <div className="admin-summary"><div><b>{complaints.length}</b><span>Total complaints</span></div><div><b>{pendingCount}</b><span>Pending</span></div><div><b>{resolvedCount}</b><span>Resolved</span></div></div>
            {complaints.length === 0 ? <div className="empty-state"><h3>No complaints to review</h3><p>New submissions will appear here.</p></div> : <div className="complaint-list">{complaints.map((item) => <AdminComplaint key={item.id} item={item} onUpdate={updateComplaint} />)}</div>}
          </section>
        )}

        {page === "search" && (
          <section className="content-panel">
            <span className="eyebrow">FIND AN ISSUE</span><h2>Search complaint records</h2>
            <input className="search-input" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by reference, title, category or description..." />
            <div className="complaint-list">{matchingComplaints.map((item) => <ComplaintCard key={item.id} item={item} />)}</div>
            {matchingComplaints.length === 0 && <p className="muted">No matching complaint records found.</p>}
            <p className="field-note">For privacy, this demo search is available only in the admin workspace in a production application.</p>
          </section>
        )}

        {page === "help" && (
          <section className="content-panel help-panel">
            <span className="eyebrow">SUPPORT CENTRE</span><h2>Frequently asked questions</h2>
            {faqs.map(([question, answer]) => <article className="faq" key={question}><h3>{question}</h3><p>{answer}</p></article>)}
          </section>
        )}
      </main>

      <footer><div className="footer-inner"><div><strong>ComplainEase</strong><p>Making complaint resolution clearer and easier.</p></div><div className="footer-links"><button onClick={() => setPage("help")}>Help centre</button><button onClick={openAdmin}>Admin demo</button></div></div><div className="copyright">© {new Date().getFullYear()} ComplainEase · Student project prototype</div></footer>
    </div>
  );
}

function ComplaintCard({ item }: { item: Complaint }) {
  return <article className="complaint-card">
    <div className="complaint-card-top"><span className="reference">{item.id}</span><StatusBadge status={item.status} /></div>
    <h3>{item.title}</h3><p className="complaint-description">{item.description}</p>
    <div className="metadata"><span>{item.category}</span><span>Submitted {new Date(item.createdAt).toLocaleString()}</span></div>
    {item.attachmentName && <p className="field-note">Supporting document name: {item.attachmentName}</p>}
    <div className="feedback"><b>Latest feedback</b><p>{item.feedback}</p></div>
  </article>;
}

function AdminComplaint({ item, onUpdate }: { item: Complaint; onUpdate: (id: string, status: Status, feedback: string) => void }) {
  const [status, setStatus] = useState<Status>(item.status);
  const [feedback, setFeedback] = useState(item.feedback);
  useEffect(() => { setStatus(item.status); setFeedback(item.feedback); }, [item.status, item.feedback]);
  return <article className="complaint-card admin-card">
    <div className="complaint-card-top"><span className="reference">{item.id}</span><StatusBadge status={item.status} /></div>
    <h3>{item.title}</h3><p className="complaint-description">{item.description}</p>
    <div className="metadata"><span>{item.category}</span><span>{item.userName} · {item.email}</span><span>{new Date(item.createdAt).toLocaleString()}</span></div>
    {item.attachmentName && <p className="field-note">Attachment name: {item.attachmentName}</p>}
    <div className="admin-controls"><label>Update status<select value={status} onChange={(e) => setStatus(e.target.value as Status)}><option>Pending</option><option>In Progress</option><option>Resolved</option><option>Rejected</option></select></label><label>Feedback<textarea rows={2} value={feedback} onChange={(e) => setFeedback(e.target.value)} /></label><button className="primary-btn" onClick={() => onUpdate(item.id, status, feedback)}>Save update</button></div>
  </article>;
}

function StatusBadge({ status }: { status: Status }) {
  return <span className={`status-badge ${status.toLowerCase().replace(" ", "-")}`}>{status}</span>;
}